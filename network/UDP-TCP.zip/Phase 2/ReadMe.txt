Name: James Lynch
Files:
	*minions.jpg (File being sent)
	*snd.py (Sender application)
	*recv.py (Reciever application)
	*newImg.jpg (Is created by recv.py program)

Execution:
	*Delete initial newImg.jpg
	*Run recv.py
	*Run snd.py
	*newImg.jpg should appear again in folder with image