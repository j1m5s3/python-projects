import socket
import sys
import os
import time

address = ("127.0.0.1", 12000)#address and port number of receiver
sndSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)#UDP socket
sndFile = open('minions.jpg', 'rb')#opens jpg file to read in binary
Fsize = sys.getsizeof(sndFile)#gets size of file
print(Fsize)
print("Sending file...")
data = sndFile.read(1024)#reads a 1024 byte chunk of the file to data
i = 0
while (data):#loops until all data is sent
    print("Sending file packets...")
    sndSocket.sendto(data, address)#sends data chunks to receiver via address
    i += 1
    sndSocket.sendto(bytes([i]), address)
    data = sndFile.read(1024)#reads the next chunk
sndFile.close()#closes original file
print ("Done sending.")
sndSocket.close()#closes socket
