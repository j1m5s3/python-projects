import socket
import sys
import os
import struct

address = ("127.0.0.1", 12000)
rcvSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)#UDP socket
rcvSocket.bind(address)#binds receiver to IP and port
print("Receiver is ready to receive...")
rcvdFile = open('newImg.jpg', 'wb')#opens an empty file to write binary
data = 1
while (data):#receiver waits in loop for sender to send
    data = rcvSocket.recv(1024)#receives data chunk from sender
    seqNUM = rcvSocket.recv(1024)
    
    print(int.from_bytes(seqNUM, byteorder = 'big'))
    Fsize = sys.getsizeof(data)#gets size of data chunk
    print (Fsize)
    print("Packet recieved...")
    if (sys.getsizeof(data) < 1041):#will execute if data chunk < 1041 bytes
        rcvdFile.write(data)#writes last chunk to new file
        print("Data written to file.")
        print ("File recieved.")
        rcvdFile.close()#close new file
        print("newImg.jpg has been closed")
        rcvSocket.shutdown(1)#closes socket
        print('Socket closed')
        sys.exit()#stops program
    rcvdFile.write(data)#writes data to new file
    print("Data written to file.")



