import socket #Socket libraries
port = 12000 #Server port
serverSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) #Determines IPv4 use and UDP 
address = ("127.0.0.1", port) #Server address
serverSocket.bind(address) #Binds the server socket to the address
print "Server is ready to recieve" #Prints to screen that the server is ready
while 1: #Infinite loop so the the server is always ready to respond
        message, clientAddress = serverSocket.recvfrom(2048) #Creates a 2048 bit buffer and stores the client message and client address
        modifiedMessage = message.upper() #Modifies client message to all uppercase
        serverSocket.sendto(modifiedMessage, clientAddress) #Sends modified message to the client
        



    
