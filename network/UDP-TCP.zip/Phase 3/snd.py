import socket
import sys
import os
import math

def getSize(fileOBJ):
    fileOBJ.seek(0,2)
    size = fileOBJ.tell()
    fileOBJ.seek(0)
    return size

RECVaddress = ("127.0.0.1", 12003)
SNDaddress = ("127.0.0.1", 12004)
sndSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sndSocket.bind(SNDaddress)
sndFile = open('minions.jpg', 'rb')
fSIZE = getSize(sndFile)
totalPkts = math.ceil(fSIZE/1024)
print("Size: ", fSIZE,", Pkt#: ", totalPkts)
fDATA = sndFile.read(1024)
seqNUM = 0
ACK = 0
while fDATA:
    sndSocket.sendto(fDATA, RECVaddress)
    print("Sending file packet...")
    sndSocket.sendto(bytes([seqNUM]), RECVaddress)
    print("Sending seqNUM...")
    ACKmsg, address = sndSocket.recvfrom(1024)
    print("Waiting for ACK0...")
    if(ACK == int.from_bytes(ACKmsg, byteorder = 'big')):
        fDATA = sndFile.read(1024)
        seqNUM += 1
        print("Received ACK0.")
    else:
        sndFile.close()
        sndSocket.close()
sndFile.close()
print("File sent.")
sndSocket.close()
print("Socket closed.")
        
    
    


    

           
           

           
       
    

       



