import socket #Allows the use of socket libraries
import time #Allows use of time library
port = 12000 #Corresponding server port
address = ("127.0.0.1", port) #Destination address
clientSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) #Determines using IPv4 (AF_INET) and UDP (SOCK_DGRAM)
message = raw_input('Input: ') #User input
clientSocket.sendto(message, address) #Takes the message and sends is to the destination address
modifiedMessage, serverAddress = clientSocket.recvfrom(2048) #Stores the modified message from the server and the source address with 2048 bit buffer size 
print modifiedMessage #Prints the server message
time.sleep(10) #Program waits 10 secs before closing
clientSocket.close #Closes the client side






