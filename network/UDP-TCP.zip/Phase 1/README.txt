James Lynch
6/11/2018
Network Design
Prof Arash
						Phase 1

Files Submitted:
Client.py
Server.py

How to run:

First run Server.py, this will esablish the server side then run Client.py and enter a 
a message, all lower case. The server will return the message in upper case.  