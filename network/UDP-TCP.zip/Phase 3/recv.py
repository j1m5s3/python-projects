import socket
import sys
import os

RECVaddress = ("127.0.0.1", 12003)
SNDaddress = ("127.0.0.1", 12004)
rcvSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
rcvSocket.bind(RECVaddress)
print("Receiver is ready to receive...")
rcvdFile = open('newImg.jpg', 'wb')
data = 1
while data:
    fDATA = rcvSocket.recv(1024)
    seqNUM = rcvSocket.recv(1024)
    print("seqNUM: ",int.from_bytes(seqNUM, byteorder = 'big'))
    print("Packet recieved...")
    rcvSocket.sendto(bytes([0]), SNDaddress)
    if(sys.getsizeof(fDATA) < 1041):
        rcvdFile.write(fDATA)
        print("Data written to file.")
        print("File recieved.")
        rcvdFile.close()
        print("newImg.jpg has been closed")
        rcvSocket.shutdown(1)
        print("Socket closed")
        sys.exit()
    rcvdFile.write(fDATA)
    print("Data written to file.")
              
    
    
    
